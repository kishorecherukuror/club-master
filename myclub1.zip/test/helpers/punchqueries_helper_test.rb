require 'test_helper'

class PunchqueriesHelperTest < ActionView::TestCase
end
