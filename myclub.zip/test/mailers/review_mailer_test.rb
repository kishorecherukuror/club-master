require 'test_helper'

class ReviewMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
