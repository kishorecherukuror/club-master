require 'test_helper'

class PunchTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
