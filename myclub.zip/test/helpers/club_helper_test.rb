require 'test_helper'

class ClubHelperTest < ActionView::TestCase
end
