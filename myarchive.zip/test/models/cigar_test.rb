require 'test_helper'

class CigarTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
