require 'test_helper'

class ProductReviewsHelperTest < ActionView::TestCase
end
