class AddDeviseToUsers < ActiveRecord::Migration
  def self.up
    #
  end
end
